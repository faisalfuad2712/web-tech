<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database</title>
</head>
<body>
    <?php
        $conn = mysqli_connect("localhost", "root", '', 'myDatabase'); 
        if (!$conn) { die("Connection failed: " . mysqli_connect_error()); } 
        echo "connetted <br>"; 
    ?>
</body>
</html>